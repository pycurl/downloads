global_cleanup() -> None

Cleanup curl environment.

Corresponds to `curl_global_cleanup`_ in libcurl.

.. _curl_global_cleanup: http://curl.haxx.se/libcurl/c/curl_global_cleanup.html
