.. _curlobject:

Curl Object
===========

.. autoclass:: pycurl.Curl

    Curl objects have the following methods:

    .. automethod:: pycurl.Curl.close

    .. automethod:: pycurl.Curl.setopt

    .. automethod:: pycurl.Curl.perform

    .. automethod:: pycurl.Curl.getinfo

    .. automethod:: pycurl.Curl.reset

    .. automethod:: pycurl.Curl.unsetopt

    .. automethod:: pycurl.Curl.pause

    .. automethod:: pycurl.Curl.errstr
