/* Generated file - do not edit. */
/* See doc/docstrings/ *.rst. */

extern const char curl_doc[];
extern const char curl_close_doc[];
extern const char curl_errstr_doc[];
extern const char curl_errstr_raw_doc[];
extern const char curl_getinfo_doc[];
extern const char curl_getinfo_raw_doc[];
extern const char curl_pause_doc[];
extern const char curl_perform_doc[];
extern const char curl_perform_rb_doc[];
extern const char curl_perform_rs_doc[];
extern const char curl_reset_doc[];
extern const char curl_set_ca_certs_doc[];
extern const char curl_setopt_doc[];
extern const char curl_setopt_string_doc[];
extern const char curl_unsetopt_doc[];
extern const char multi_doc[];
extern const char multi_add_handle_doc[];
extern const char multi_assign_doc[];
extern const char multi_close_doc[];
extern const char multi_fdset_doc[];
extern const char multi_info_read_doc[];
extern const char multi_perform_doc[];
extern const char multi_remove_handle_doc[];
extern const char multi_select_doc[];
extern const char multi_setopt_doc[];
extern const char multi_socket_action_doc[];
extern const char multi_socket_all_doc[];
extern const char multi_timeout_doc[];
extern const char pycurl_global_cleanup_doc[];
extern const char pycurl_global_init_doc[];
extern const char pycurl_module_doc[];
extern const char pycurl_version_info_doc[];
extern const char share_doc[];
extern const char share_close_doc[];
extern const char share_setopt_doc[];
