import pycurl

def setup_package():
    print('Testing %s' % pycurl.version)
